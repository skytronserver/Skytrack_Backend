declare namespace _default {
    let PROPERTYCHANGE: string;
}
export default _default;
export type Types = 'propertychange';
//# sourceMappingURL=ObjectEventType.d.ts.map