export default ResourceId;
/**
 * @classdesc
 *
 * @abstract
 */
declare class ResourceId extends Filter {
    /**
     * @type {!string}
     */
    rid: string;
}
import Filter from './Filter.js';
//# sourceMappingURL=ResourceId.d.ts.map