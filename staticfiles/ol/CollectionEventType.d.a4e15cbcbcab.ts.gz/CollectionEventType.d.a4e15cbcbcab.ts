declare namespace _default {
    let ADD: string;
    let REMOVE: string;
}
export default _default;
//# sourceMappingURL=CollectionEventType.d.ts.map